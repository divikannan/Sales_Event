﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesEvent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesEvent.Api
{
    [ApiController]
    [Route("api/[controller]")]

    public class EntityController : ControllerBase
    {
        private ISalesEventRepository _repo;
        public EntityController(ISalesEventRepository repo)
        {
            _repo = repo;
        }

        [HttpPost]
        [Route("PostEntity")]
        public IActionResult PostEntity(SalesEventEntity model)
        {
            _repo.Add(model);
            return Ok("Success");
        }

 
    }
}
