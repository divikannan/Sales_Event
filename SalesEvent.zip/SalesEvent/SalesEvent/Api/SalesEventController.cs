﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesEvent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SalesEvent.Api
{
    [Route("api/SalesEvent")]
    public class SalesEventController : Controller
    {
        private ISalesEventRepository _repo;
        public SalesEventController(ISalesEventRepository repo)
        {
            _repo = repo;
        }

        [HttpPost]
        [Route("PostEntity")]
        public IActionResult PostEntity(SalesEventEntity model)
        {
            _repo.Add(model);
            return Ok("Success");
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
