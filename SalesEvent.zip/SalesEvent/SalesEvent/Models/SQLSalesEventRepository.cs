﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesEvent.Models
{
    public class SQLSalesEventRepository:ISalesEventRepository
    {
        public AppDbContext _context;
        public SQLSalesEventRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<SalesEventEntity> Add(SalesEventEntity entity)
        {
            _context.SalesEvents.Add(entity);
            _context.SaveChanges();
            return entity;
        }

        public SalesEventEntity Delete(int id)
        {
            var item = _context.SalesEvents.Find(id);
            if(item != null)
            {
                _context.SalesEvents.Remove(item);
                _context.SaveChanges();
            }
            return item;
        }

        public IEnumerable<SalesEventEntity> GetList()
        {
            return _context.SalesEvents;
        }
        

        public SalesEventEntity Update(SalesEventEntity entityChanges)
        {
            var emp = _context.SalesEvents.Attach(entityChanges);
            emp.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();
            return entityChanges;
        }
    }
}
