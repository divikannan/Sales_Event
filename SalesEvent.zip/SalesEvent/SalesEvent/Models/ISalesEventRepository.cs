﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesEvent.Models
{
    public interface ISalesEventRepository
    {
        IEnumerable<SalesEventEntity> GetList();
        Task<SalesEventEntity> Add(SalesEventEntity entity);
        SalesEventEntity Update(SalesEventEntity entityChanges);
        SalesEventEntity Delete(int id);
    }
}
