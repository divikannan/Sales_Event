﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SalesEvent.Models
{
    public class SalesEventEntity
    {
        public int Id { get; set; }
        public decimal? SellingPrice { get; set; }
        public string DiscountType { get; set; }
        [Required ]
        [Range(1, int.MaxValue, ErrorMessage = "Please enter a value bigger than {1}")] 
        public decimal DiscountAmount { get; set; }
        public decimal? EventPrice { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        public DateTime EndDate { get; set; }

    }
    
}
