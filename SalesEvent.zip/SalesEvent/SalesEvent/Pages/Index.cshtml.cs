﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using SalesEvent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesEvent.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly ISalesEventRepository _salesEventRepo;
        public IndexModel(ILogger<IndexModel> logger, ISalesEventRepository salesEventRepo)
        {
            _logger = logger;
            _salesEventRepo = salesEventRepo;
        }
        [BindProperty]
        public SalesEventEntity Item { get; set; }

        public string SuccessMessage { get; set; }

        public async Task OnGetAsync()
        {
            Item = new SalesEventEntity();

        }

        public async Task OnPostAsync()
        {
            if (Item != null)
            {
                if (!ModelState.IsValid)
                {
                    return;
                }
                if (Item.DiscountAmount == 0)
                {
                    return;
                }
                try
                {
                    await _salesEventRepo.Add(Item);
                    SuccessMessage = "Information Saved Successfully";
                }
                catch(Exception ex)
                {
                    throw ex;
                }
            }

        }
    }
}
