﻿import Vue from 'vue';


const app = new Vue({

});